<!--
Note that leaving sections blank will make it difficult for us to troubleshoot and we may have to close the issue.
-->

**What version of angular-loading-bar are you using?**

**What version of AngularJS are you using?**

**What browsers are affected?**

**Please provide either a JSFiddle, Plunkr example that replicates the issue**

**Please describe the issue**

**What did you expect to happen?**

**What actually happened?**
